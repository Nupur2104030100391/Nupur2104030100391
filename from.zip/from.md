<DOCTYPE html>
    <html lan="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewpoint" content="width=device-width, initial-scale=1.0">
            <title>Document</title> 
        </head>
        <body>
            <form>
                enter your first name
                <input type="text"name="frame" passcode="enter your name">
            </br><br>
            enter your last name
            <input type="text" name="Iname">
        <br>
        enter your password
        <input type="password" name="pwd"
        <br>
        my favourite colour
        <input type="checkbox" name="black"> black color
        <input type="checkbox" name="blue"> blue color
        <input type="checkbox" name="pink"> pink color
        <input type="checkbox" name="green"> green color
        <br></br>
        <head>gander</head>
        <input type="radio" id="G1" name="Gander"><label for="G1">Male</label> 
        </br>
        enter your address
        <textarea rows="5" cols="30"></textarea>
        <br></br>
        enter your email
        <input type="email" name="eid">
        <br></br>
        select your country
        <select name="country">
        <option value="1">india</option>
         <option value="2">u.s.a</option>
        <option value="3">canada </option>
        </select>
            <br></br>
            enter your DOB
            <input type="submit" value="submit">
            <br></br>
            <input type="reset" value="reset">
        </form>
        </body>
           </html>